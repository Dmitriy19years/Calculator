﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Application = System.Windows.Forms.Application;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Calcul calcul;
        public char znak = ' ';
        public int a = 0;
        public int b = 0;
        public string num;
        public int result;
        public Form1()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            button2.Enabled = false;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 2;
            Numbr("2");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 1;
            Numbr("1");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }
        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 3;
            Numbr("3");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 4;
            Numbr("4");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 5;
            Numbr("5");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 6;
            Numbr("6");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 7;
            Numbr("7");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 8;
            Numbr("8");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 9;
            Numbr("9"); 
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + 0;
            Numbr("0");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (znak == ' ' && textBox1.Text != "")
            {
                textBox1.Text = textBox1.Text + "+";
                znak = '+';
                num = "";
            }
            else if (znak == ' ' && textBox1.Text == "")
            {
                textBox1.Text = textBox1.Text + "0+";
                znak = '+';
                num = "";
            }
            else
            {
                textBox1.Text = result.ToString();
                a = result;
                textBox1.Text = textBox1.Text + "+";
                znak = '+';
                num = "";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (znak == ' ' && textBox1.Text != "")
            {
                textBox1.Text = textBox1.Text + "-";
                znak = '-';
                num = "";
            }
            else if (znak == ' ' && textBox1.Text == "")
            {
                textBox1.Text = textBox1.Text + "0-";
                znak = '-';
                num = "";
            }
            else
            {
                textBox1.Text = result.ToString();
                a = result;
                textBox1.Text = textBox1.Text + "-";
                znak = '-';
                num = "";
            }

        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (znak == ' ' && textBox1.Text != "")
            {
                textBox1.Text = textBox1.Text + "*";
                znak = '*';
                num = "";
            }
            else if (znak == ' ' && textBox1.Text == "")
            {
                textBox1.Text = textBox1.Text + "0*";
                znak = '*';
                num = "";
            }
            else
            {
                textBox1.Text = result.ToString();
                a = result;
                textBox1.Text = textBox1.Text + "*";
                znak = '*';
                num = "";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (znak == ' ' && textBox1.Text != "")
            {
                textBox1.Text = textBox1.Text + "/";
                znak = '/';
                num = "";
            }
            else if (znak == ' ' && textBox1.Text == "")
            {
                textBox1.Text = textBox1.Text + "0/";
                znak = '/';
                num = "";
            }
            else
            {
                textBox1.Text = result.ToString();
                a = result;
                textBox1.Text = textBox1.Text + "/";
                znak = '/';
                num = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            label2.Text = "0";
            znak = ' ';
            num = "";
            a = 0;
            b = 0;
            result = 0;
            button2.Enabled = false;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            a = result;
            textBox1.Text = label2.Text;
            znak = ' ';
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text[0] != '-' )
            {
                button2.Enabled = true;
                textBox1.Text = "-" + textBox1.Text; 
                a = a * (-1);
                calcul = new Calcul(a, b, znak);
                result = calcul.Operation();
                label2.Text = result.ToString();
                if (result == 0)
                {
                    label2.Text = textBox1.Text;
                }

            }
            else if (textBox1.Text[0] == '-')
            {
                button2.Enabled = true;
                textBox1.Text = textBox1.Text.Remove(0,1);
                a = a * (-1);
                calcul = new Calcul(a, b, znak);
                result = calcul.Operation();
                label2.Text = result.ToString();
                if (result == 0)
                {
                    label2.Text = textBox1.Text;
                }
            }
        }
        public void Numbr(string number)
        {
            button2.Enabled = true;
            if (znak == ' ')
            {
                num = num + number;
                label2.Text = num;
                a = int.Parse(num);
            }
            else
            {
                num = num + number;
                b = int.Parse(num);
                calcul = new Calcul(a, b, znak);
                result = calcul.Operation();
                label2.Text = result.ToString();
            }
            if (znak == '/' && b == 0)
            {
                textBox1.Clear();
                label2.Text = "0";
                znak = ' ';
                num = "";
                a = 0;
                b = 0;
                result = 0;
                button2.Enabled = false;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (this.BackColor == Color.PeachPuff)
            {
                this.BackColor = Color.DimGray;
            }
            else
            {
                this.BackColor = Color.PeachPuff;
            }
        }
    }
}
